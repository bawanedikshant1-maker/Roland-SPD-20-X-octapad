package com.example.octapad

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView

class MainActivity : Activity() {
    private var cb: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.setBackgroundColor(0xFF0B0B0C.toInt())
        w.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView, c: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                cb?.onReceiveValue(null); cb = c
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                startActivityForResult(i, 1)
                return true
            }
        }
        w.loadUrl("file:///android_asset/index.html")
        setContentView(w)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 1) {
            val r: Array<Uri>? = if (res == RESULT_OK && d != null)
                d.clipData?.let { cd -> Array(cd.itemCount) { cd.getItemAt(it).uri } } ?: d.data?.let { arrayOf(it) }
            else null
            cb?.onReceiveValue(r); cb = null
        }
    }
}
